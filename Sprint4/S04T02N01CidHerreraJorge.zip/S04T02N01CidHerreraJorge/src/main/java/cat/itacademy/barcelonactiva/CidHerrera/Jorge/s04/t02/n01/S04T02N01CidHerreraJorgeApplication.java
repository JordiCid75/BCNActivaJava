package cat.itacademy.barcelonactiva.CidHerrera.Jorge.s04.t02.n01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S04T02N01CidHerreraJorgeApplication {

	public static void main(String[] args) {
		SpringApplication.run(S04T02N01CidHerreraJorgeApplication.class, args);
	}

}

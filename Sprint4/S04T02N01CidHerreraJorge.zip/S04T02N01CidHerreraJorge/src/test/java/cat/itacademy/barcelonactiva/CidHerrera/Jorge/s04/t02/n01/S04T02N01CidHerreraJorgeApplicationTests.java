package cat.itacademy.barcelonactiva.CidHerrera.Jorge.s04.t02.n01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S04T02N01CidHerreraJorgeApplicationTests {

	@Test
	void contextLoads() {
	}

}

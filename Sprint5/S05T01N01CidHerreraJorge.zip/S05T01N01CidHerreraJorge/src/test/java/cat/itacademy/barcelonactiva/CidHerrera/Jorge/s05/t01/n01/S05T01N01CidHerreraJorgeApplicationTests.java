package cat.itacademy.barcelonactiva.CidHerrera.Jorge.s05.t01.n01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S05T01N01CidHerreraJorgeApplicationTests {

	@Test
	void contextLoads() {
	}

}
